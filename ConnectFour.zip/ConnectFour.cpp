#include <iostream>
#include <vector>

using namespace std;

const int ROWS = 6;
const int COLS = 7;

void printBoard(const vector<vector<char>>& board) {
    cout << "\n";
    for (int row = 0; row < ROWS; ++row) {
        cout << "|";
        for (int col = 0; col < COLS; ++col) {
            cout << (board[row][col] == ' ' ? '.' : board[row][col]) << "|";
        }
        cout << "\n";
    }
    cout << " ";
    for (int col = 0; col < COLS; ++col) cout << col << " ";
    cout << "\n";
}

bool isValidMove(const vector<vector<char>>& board, int col) {
    return col >= 0 && col < COLS && board[0][col] == ' ';
}

int makeMove(vector<vector<char>>& board, int col, char player) {
    for (int row = ROWS - 1; row >= 0; --row) {
        if (board[row][col] == ' ') {
            board[row][col] = player;
            return row;
        }
    }
    return -1;
}

bool checkDirection(const vector<vector<char>>& board, int r, int c, int dr, int dc, char player) {
    int count = 0;
    for (int i = 0; i < 4; ++i) {
        int nr = r + i * dr, nc = c + i * dc;
        if (nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS && board[nr][nc] == player) {
            count++;
        } else {
            break;
        }
    }
    return count == 4;
}

bool isWinningMove(const vector<vector<char>>& board, int r, int c, char player) {
    return checkDirection(board, r, c, 0, 1, player) ||
           checkDirection(board, r, c, 1, 0, player) ||
           checkDirection(board, r, c, 1, 1, player) ||
           checkDirection(board, r, c, 1, -1, player);
}

bool isFull(const vector<vector<char>>& board) {
    for (int col = 0; col < COLS; ++col) {
        if (board[0][col] == ' ') return false;
    }
    return true;
}

int main() {
    vector<vector<char>> board(ROWS, vector<char>(COLS, ' '));
    char currentPlayer = 'X';

    cout << "=== Connect Four ===\n";
    printBoard(board);

    while (true) {
        int col;
        cout << "Player " << currentPlayer << ", choose column (0-" << COLS - 1 << "): ";
        cin >> col;

        if (!isValidMove(board, col)) {
            cout << "Invalid move. Try again.\n";
            continue;
        }

        int row = makeMove(board, col, currentPlayer);
        printBoard(board);

        if (isWinningMove(board, row, col, currentPlayer)) {
            cout << "Player " << currentPlayer << " wins!\n";
            break;
        }

        if (isFull(board)) {
            cout << "It's a draw!\n";
            break;
        }

        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    }

    return 0;
}